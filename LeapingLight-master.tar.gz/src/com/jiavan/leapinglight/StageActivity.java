package com.jiavan.leapinglight;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.LinearLayout;

public class StageActivity extends Activity{

	private int startX;
	private int endX;
	private int screenWidth;
	private BluetoothLeClass mBLE;
	private BleParcelable parcel;
	private LinearLayout llCricle;
	private String deviceAdress;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_stage);
		Constant.gattWriteServices(mBLE.getSupportedGattServices(), Constant.LIGHT_ON, mBLE);
	}
	
	private void initData(){
		this.startX = 0;
		this.endX = 0;
		WindowManager wm = this.getWindowManager();
		this.screenWidth = wm.getDefaultDisplay().getWidth();
		
		mBLE = new BluetoothLeClass(this);
		Intent intent = this.getIntent();
		deviceAdress = intent.getStringExtra("adress");
		mBLE.connect(deviceAdress);
		
		/*llCricle = (LinearLayout)findViewById(R.id.ll_circle);
		LayoutParams lp = llCricle.getLayoutParams();
		lp.width = (int)this.screenWidth / 2;		dest.writeValue(mBLE);
		lp.height = lp.width;
		llCricle.setLayoutParams(lp);*/
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		int x = (int)event.getX();
		if(event.getAction() == MotionEvent.ACTION_DOWN){
			this.startX = x;
		}
		if(event.getAction() == MotionEvent.ACTION_UP){
			this.endX = x;
			if((endX - startX) > (this.screenWidth / 3)){
				/*Intent intent = new Intent();
				intent.setClass(StageActivity.this, MainActivity.class);
				StageActivity.this.startActivity(intent);*/
				finish();
				overridePendingTransition(R.anim.in_from_left,R.anim.out_to_right);
			}
		}
		return super.onTouchEvent(event);
	}
}
