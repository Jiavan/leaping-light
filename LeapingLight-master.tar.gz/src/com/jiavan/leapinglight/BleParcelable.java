package com.jiavan.leapinglight;

import android.os.Parcel;
import android.os.Parcelable;

public class BleParcelable implements Parcelable{

	private BluetoothLeClass mBLE;
	
	public BleParcelable(BluetoothLeClass mBle){
		this.mBLE = mBle;
	}
	
	public BluetoothLeClass getBLE(){
		return this.mBLE;
	}
	
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int arg1) {
		// TODO Auto-generated method stub
		dest.writeValue(mBLE);
	}

}
